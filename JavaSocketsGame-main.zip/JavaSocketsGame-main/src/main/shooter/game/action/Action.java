package src.main.shooter.game.action;

// TODO: Split instant and long actions
public enum Action {
    LEFT_WALK, RIGHT_WALK, JUMP, SHOOT;
}
