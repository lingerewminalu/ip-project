package src.main.shooter.game.entities;

public enum XAxisType {
    LEFT, CENTER, RIGHT;
}
