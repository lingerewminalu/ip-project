package src.main.shooter.game.entities;

public enum YAxisType {
    TOP, CENTER, BOTTOM;
}
