package src.main.shooter.net.packets;

import java.io.Serializable;

public class ServerPacket implements Serializable {

}
