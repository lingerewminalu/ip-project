Chat copied off of WittCode: https://www.youtube.com/watch?v=gLfuZrrfKes

Game inspired by vanZeben: https://www.youtube.com/watch?v=l1p21JWa_8s&list=PL8CAB66181A502179&index=17